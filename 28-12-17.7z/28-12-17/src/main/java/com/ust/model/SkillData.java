package com.ust.model;

import java.util.HashSet;
import java.util.Set;

public class SkillData {

	public SkillData() {
	}

	private int skillId;
	private String skillName;
	// many-to-many-mapping
	private Set<EmployeeData> employeeData = new HashSet<EmployeeData>();

	public int getSkillId() {
		return skillId;
	}

	public void setSkillId(int skillId) {
		this.skillId = skillId;
	}

	public String getSkillName() {
		return skillName;
	}

	public void setSkillName(String skillName) {
		this.skillName = skillName;
	}

	public Set<EmployeeData> getEmployeeData() {
		return employeeData;
	}

	public void setEmployeeData(Set<EmployeeData> employeeData) {
		this.employeeData = employeeData;
	}

	
}

package com.ust.model;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class StoreData {
	public static void main(String[] args) {

		System.out.println("Hibernate Many to Many (XML mapping)");
		Session session = HibernateUtil.getSessionFactory().openSession();

		session.beginTransaction();

		EmployeeData e1 = new EmployeeData();
		e1.setEmpFirstName("First");
		e1.setEmpLastName("Name");
		e1.setEmpDepartment("Development");

		EmployeeData e2 = new EmployeeData();
		e2.setEmpFirstName("Second");
		e2.setEmpLastName("Name");
		e2.setEmpDepartment("Support");

		EmployeeData e3 = new EmployeeData();
		e3.setEmpFirstName("Third");
		e3.setEmpLastName("Name");
		e3.setEmpDepartment("Management");

		SkillData s1 = new SkillData();
		s1.setSkillName("Excel");

		SkillData s2 = new SkillData();
		s2.setSkillName("Java");

        Set<SkillData> skillData = new HashSet<SkillData>();
        skillData.add(s1);
        skillData.add(s2);
        e1.setSkillData(skillData);
        
        
        
		session.persist(e1);// persisting the object
		/*
		
		// queries all products
        List<EmployeeData> listEmployees = session.createQuery("from EmployeeData").list();
        for (EmployeeData aEmp : listEmployees) {
            String info = "FirstName: " + aEmp.getEmpFirstName() + "\n";
            info += "LastName: " + aEmp.getEmpLastName() + "\n";
            info += "Department:" + aEmp.getEmpDepartment() + "\n";
             
            SkillData aDetail = aEmp.getSkillData();
            info += "Skill Name: " + aDetail.getSkillName()+ "\n";
             
            System.out.println(info);
        }*/
		session.getTransaction().commit();
		System.out.println("successfully saved all the table");

	}

}

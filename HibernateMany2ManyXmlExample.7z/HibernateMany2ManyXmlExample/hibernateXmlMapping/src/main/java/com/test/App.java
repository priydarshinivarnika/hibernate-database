package com.test;

import java.util.HashSet;
import java.util.Set;

import org.apache.log4j.Logger;
import org.hibernate.Session;

import com.test.model.Category;
import com.test.model.Stock;
import com.test.util.HibernateUtil;
public class App {
	final static Logger logger = Logger.getLogger(App.class);
	public static void main(String[] args) {
		System.out.println("Hibernate many to many (XML Mapping)");
		Session session = HibernateUtil.getSessionFactory().openSession();
		for(int i=1;i<=10;i++){
			
		session.beginTransaction();

		
			Stock stock = new Stock();
			stock.setStockCode("7052"+i);
			stock.setStockName("PADINI"+i);
			Category category = new Category("CONSUMER"+i, "CONSUMER COMPANY"+i);
			Set<Category> categories = new HashSet<Category>();
			categories.add(category);
			stock.setCategories(categories);
			session.save(stock);
			session.getTransaction().commit();
			
		}
		
		/*Category category1 = new Category("CONSUMER", "CONSUMER COMPANY");
		Category category2 = new Category("INVESTMENT", "INVESTMENT COMPANY");

		Set<Category> categories = new HashSet<Category>();
		categories.add(category1);
		categories.add(category2);

		stock.setCategories(categories);

		session.save(stock);
		session.getTransaction().commit();
*/
		
		System.out.println("Done");
	}

}

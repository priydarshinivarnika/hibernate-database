package com.test.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.test.dao.StudentDAOImpl;
import com.test.model.Student;

@RestController
public class StudentController {
	@Autowired
	private StudentDAOImpl studentDAOImpl;

	/*** Creating a new Student ***/
	@RequestMapping(value = StudentUriConstants.CREATE_Std, method = RequestMethod.POST, produces = "application/json", consumes = "application/json")
	public void createStudent(@RequestBody Student student) {
		studentDAOImpl.createStudent(student);
	}

	/*** Retrieve a single Student ***/
	@RequestMapping(value = StudentUriConstants.GET_Std, produces = "application/json", method = RequestMethod.GET)
	public Student getStudentById(@PathVariable("id") long id) {
		Student student = studentDAOImpl.getStudentById(id);
		return student;
	}

	/*** Retrieve all Students ***/
	@RequestMapping(value = StudentUriConstants.GET_ALL_Std, produces = "application/json", method = RequestMethod.GET)
	public List getAllStudents() {
		List studentList = studentDAOImpl.getAllStudents();
		return studentList;
	}

	/*** Update a Student ***/
	@RequestMapping(value = StudentUriConstants.UPDATE_Std, method = RequestMethod.PUT, produces = "application/json", consumes = "application/json")
	public void updateStudent(@RequestBody Student student) {
		studentDAOImpl.updateStudent(student);
	}

	/*** Delete a Student ***/
	@RequestMapping(value = StudentUriConstants.DELETE_Std, method = RequestMethod.DELETE, produces = "application/json")
	public void deleteStudent(@PathVariable("id") long id) {
		studentDAOImpl.deleteStudent(id);
	}

}

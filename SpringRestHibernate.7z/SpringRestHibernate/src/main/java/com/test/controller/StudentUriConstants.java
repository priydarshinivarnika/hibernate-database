package com.test.controller;

public class StudentUriConstants {
	
	public static final String CREATE_Std = "/create";
	public static final String GET_Std = "/student/{id}";
	public static final String GET_ALL_Std = "/students";
	public static final String UPDATE_Std = "/update";
	public static final String DELETE_Std = "/delete/{id}";
	
	}

package com.ust.model;

import java.util.Set;

public interface EmployeeServices {
	public abstract Integer addEmployee(String email, String firstName,
			String lastName, String department);

	public abstract void listEmployees();

	public abstract void fetchEmployeeById(int id);

	public abstract void fetchEmployeeByDepartment(String department);

	public abstract void updateEmployee(int id, String department);

	public abstract void deleteEmployee(Integer EmployeeID);

	public abstract void countEmployee();

}
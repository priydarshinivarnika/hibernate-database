package com.ust.operation;

import java.sql.Timestamp;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Session;

import com.ust.model.Employee;
import com.ust.model.EmployeeRepository;
import com.ust.model.Skill;
import com.ust.utility.HibernateUtil;

public class StoreData {

	public static void main(String[] args) {

		final Logger log = Logger.getLogger(StoreData.class);
		System.out.println("Hibernate Many to Many (XML mapping)");
		Session session = HibernateUtil.getSessionFactory().openSession();
		session.beginTransaction();
		
		
		for (int i = 1; i <= 10; i++) {
			Employee emp = new Employee();
			emp.setFirstName("First" + i);
			emp.setLastName("Name" + i);
			emp.setDepartment("Development");
			emp.setDoJ(new Timestamp(04 - 20 - 2018));
			emp.setAddress("Trivandrum");
			emp.setSalary("400000");
			emp.setPhone(1234567890);
			emp.getSkill().add(new Skill("Java"));
			emp.getSkill().add(new Skill("Sql"));

			session.persist(emp);
			
		}

		session.getTransaction().commit();
		System.out.println("successfully saved all the table");
		EmployeeRepository empRepo = new Employee();
		empRepo.listEmployees();
		
		session.close();
		HibernateUtil.getSessionFactory().close();
	}

	
}

package com.ust.model;

import java.sql.Timestamp;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.ust.utility.HibernateUtil;

public class Employee implements EmployeeRepository {

	public Employee() {
	}

	private int id;
	private String firstName, lastName, department;
	private Timestamp doJ;
	private String address;
	private String salary;
	private long phone;
	private Set<Skill> skill = new HashSet<Skill>();

	public Employee(String firstName, String lastName, String department,
			Timestamp doJ, String address, String salary, long phone,
			Set<Skill> skill) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.department = department;
		this.doJ = doJ;
		this.address = address;
		this.salary = salary;
		this.phone = phone;
		this.skill = skill;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public Timestamp getDoJ() {
		return doJ;
	}

	public void setDoJ(Timestamp doJ) {
		this.doJ = doJ;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getSalary() {
		return salary;
	}

	public void setSalary(String salary) {
		this.salary = salary;
	}

	public long getPhone() {
		return phone;
	}

	public void setPhone(long phone) {
		this.phone = phone;
	}

	public Set<Skill> getSkill() {
		return skill;
	}

	public void setSkill(Set<Skill> skills) {
		this.skill = skills;
	}

	public  void listEmployees() {
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction tx = null;

		try {
			tx = session.beginTransaction();
			List employees = session.createQuery("FROM EmployeeData").list();
			System.out.println("List of all the Employees  are:");
			for (Iterator iterator = employees.iterator(); iterator.hasNext();) {
				Employee employee = (Employee) iterator.next();
				System.out.print(" Id: " + employee.getId());
				System.out.print(" First Name: " + employee.getFirstName());
				System.out.print(" Last Name: " + employee.getLastName());
				System.out.println(" Department: " + employee.getDepartment());
				System.out.println(" Department: " + employee.getDepartment());
				System.out.println(" DateOfJoining: " + employee.getDoJ());
				System.out.println(" Address: " + employee.getAddress());
				System.out.println(" Salary: " + employee.getSalary());
				System.out.println(" Phone: " + employee.getPhone());
				System.out.println("Skill: " + employee.getSkill());
			}
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}
	}

	public static void retriveEmployeeData()

	{

		Session session = HibernateUtil.getSessionFactory().openSession();
		session.beginTransaction();
		List employee = session.createQuery("from EmployeeData").list();

		for (Iterator iterator = employee.iterator(); iterator.hasNext();) {
			Employee employee1 = (Employee) iterator.next();
			System.out.println(employee1.getFirstName() + "  "
					+ employee1.getLastName() + "  "
					+ employee1.getDepartment() + " " + employee1.getDoJ()
					+ " " + employee1.getAddress() + " "
					+ employee1.getSalary() + " " + employee1.getPhone());
			session.persist(employee);
		}
		session.getTransaction().commit();
		session.close();
		HibernateUtil.getSessionFactory().close();
	}

	/*
	 * public void saveEmployee(String name, String city, int sal, int phone) {
	 * Session session = HibernateUtil.getSessionFactory().openSession();
	 * session.beginTransaction();
	 * 
	 * try { Employee employee = new Employee(); employee.setName("name");
	 * employee.setSal(sal); employee.setCity("city"); employee.setPhone(phone);
	 * session.save(employee); transaction.commit();
	 * System.out.println("Records inserted sucessessfully"); } catch
	 * (HibernateException e) { transaction.rollback(); e.printStackTrace(); }
	 * finally { session.close(); }
	 * 
	 * }
	 */
	
/*	public void deleteEmployee() {

		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction transaction = null;
		try {
			transaction = session.beginTransaction();
			String queryString = "from Employee where phone = :phone";
			Query query = session.createQuery(queryString);
			query.setInteger("phone", 893965);
			Employee employee = (Employee) query.uniqueResult();
			session.delete(employee);
			System.out.println("Employee records deleted!");

		} catch (HibernateException e) {

			transaction.rollback();

			e.printStackTrace();

		} finally {

			session.close();

		}
	}

	public void updateEmployee() {

		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction transaction = null;
		try {
			transaction = session.beginTransaction();
			String queryString = "from Employee where sal = :sal";
			Query query = session.createQuery(queryString);
			query.setInteger("sal", 50000);
			Employee employee = (Employee) query.uniqueResult();
			employee.setSal(60000);
			session.update(employee);
			System.out.println("Employee records updated!");
		} catch (HibernateException e) {

			transaction.rollback();

			e.printStackTrace();

		} finally {

			session.close();

		}
	}
*/

}

package com.ust.model;

public interface EmployeeRepository {

	/*public abstract Integer addEmployee(String email, String firstName,
			String lastName, String department);
*/
	public abstract void listEmployees();

	/*public abstract void fetchEmployeeById(int id);

	public abstract void fetchEmployeeByDepartment(String department);

	public abstract void updateEmployee(int id, String department);

	public abstract void deleteEmployee(Integer EmployeeID);

	public abstract void countEmployee();
*/
}

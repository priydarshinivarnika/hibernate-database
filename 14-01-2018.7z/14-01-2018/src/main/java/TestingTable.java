
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.ust.model.EmployeeEntity;
import com.ust.model.SkillEntity;
import com.ust.utility.HibernateUtil;

public class TestingTable {

	public static void main(String[] args)

	{

		Session session = HibernateUtil.getSessionFactory().openSession();
		session.beginTransaction();

		/*
		 * SkillEntity skill1 = new SkillEntity(); skill1.setName("Java");
		 * 
		 * SkillEntity skill2 = new SkillEntity(); skill2.setName("SQL");
		 * 
		 * EmployeeEntity emp1 = new EmployeeEntity();
		 * 
		 * emp1.setEmail("abc@mail.com"); emp1.setFirstName("First");
		 * emp1.setLastName("Name"); emp1.setDepartment("Physics");
		 * 
		 * EmployeeEntity emp2 = new EmployeeEntity();
		 * 
		 * emp2.setEmail("@mail.com"); emp2.setFirstName("Second");
		 * emp2.setLastName("Name"); emp2.setDepartment("Chemistry");
		 * 
		 * Set<SkillEntity> skills = new HashSet<SkillEntity>(); skills.add(skill1);
		 * skills.add(skill2);
		 * 
		 * emp1.setSkills(skills); //emp2.setSkills(skills);
		 * 
		 * // Save Employee session.save(emp1); session.save(emp2);
		 */

		// --------------------learning code---

		TestingTable emp = new TestingTable();

		// Add few employee records in database
		Integer empID1 = emp.addEmployee("abc@mail.com", "Varnika", "Priydarshini", "Dev");
		Integer empID2 = emp.addEmployee("def@mail.com", "Varnika", "Priydarshini", "Dev");
		Integer empID3 = emp.addEmployee("ghi@mail.com", "Varnika", "Priydarshini", "Dev");

		// List down all the employees
		//emp.listEmployees();

		// Update employee's records
		emp.updateEmployee(empID1, "Physics");

		// Delete an employee from the database
		// emp.deleteEmployee(empID2);

		// List down new list of the employees
		//emp.listEmployees();

		// Fetch the employee by its id
		//emp.fetchEmployeeById(2);

		// Fetch the employee by its department
		emp.fetchEmployeeByDepartment("Physics");
		

		session.getTransaction().commit();
		HibernateUtil.shutdown();

	}

	/* Method to CREATE an employee in the database */
	public Integer addEmployee(String email, String firstName, String lastName, String department) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction tx = null;
		Integer employeeID = null;

		try {
			tx = session.beginTransaction();
			EmployeeEntity employee = new EmployeeEntity(email, firstName, lastName, department);
			employeeID = (Integer) session.save(employee);
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}
		return employeeID;
	}

	/* Method to READ all the employees */
	public void listEmployees() {
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction tx = null;

		try {
			tx = session.beginTransaction();
			List employees = session.createQuery("FROM EmployeeEntity").list();
			System.out.println("List of all the Employees  are:");
			for (Iterator iterator = employees.iterator(); iterator.hasNext();) {
				EmployeeEntity employee = (EmployeeEntity) iterator.next();
				System.out.print(" Id: " + employee.getEmployeeId());
				System.out.print(" Email: " + employee.getEmail());
				System.out.print(" First Name: " + employee.getFirstName());
				System.out.print(" Last Name: " + employee.getLastName());
				System.out.println(" Department: " + employee.getDepartment());
			}
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}
	}

	// Method to READ the employee by id
	public void fetchEmployeeById(int id) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction tx = null;

		try {
			tx = session.beginTransaction();
			EmployeeEntity employee = (EmployeeEntity) session.get(EmployeeEntity.class, id);
			System.out.println("Detail of Employee whose Id is: "+id);
			System.out.print(" Id: " + employee.getEmployeeId());
			System.out.print(" Email: " + employee.getEmail());
			System.out.print(" First Name: " + employee.getFirstName());
			System.out.print(" Last Name: " + employee.getLastName());
			System.out.println(" Department: " + employee.getDepartment());

			tx.commit();
		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}
	}

	// Method to READ the employee by department
	public void fetchEmployeeByDepartment(String department) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction tx = null;

		try {
			tx = session.beginTransaction();
			System.out.println("Detail of Employee whose Department is: "+ department);
			
			Query query = session.createQuery("from EmployeeEntity where department = :code ");
			query.setParameter("code", department);
			List list = query.list();
			System.out.println(list);
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}
	}

	/* Method to UPDATE department for an employee */
	public void updateEmployee(int id, String department) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction tx = null;

		try {
			tx = session.beginTransaction();
			EmployeeEntity employee = (EmployeeEntity) session.get(EmployeeEntity.class, id);
			System.out.println("Updated Employee whose Id is: "+id);
			employee.setDepartment(department);
			session.update(employee);
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}
	}

	/* Method to DELETE an employee from the records */
	public void deleteEmployee(Integer EmployeeID) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction tx = null;

		try {
			tx = session.beginTransaction();
			EmployeeEntity employee = (EmployeeEntity) session.get(EmployeeEntity.class, EmployeeID);
			System.out.println("Deleted Employee whose Id is: "+employee.getEmployeeId());
			session.delete(employee);
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}
	}

}

package home.session.constants.registration;

public enum EntryType {
	
	INDIVIDUAL,
	ORGANISATION

}

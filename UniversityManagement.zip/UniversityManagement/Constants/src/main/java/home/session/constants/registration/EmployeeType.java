package home.session.constants.registration;

public enum EmployeeType {
	
	CONTRACT,
	PERMANENT

}

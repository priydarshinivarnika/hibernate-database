package home.session.constants.registration;

public enum Programme {
	
	UNDERGRADUATE,
	POST_GRADUATE,
	PHD

}

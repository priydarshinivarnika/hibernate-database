package home.session.connector;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class UMSConnector
 */
public class UMSConnector extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UMSConnector() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		/*PrintWriter out = response.getWriter(); 
		out.println("This is from doGet()");
		// Read values from servlet request.
		String name = request.getParameter("username");
		out.println("Hello " + name + "! How are you?");
		out.println("Following are the headers.. ");
		out.println("Context Path : " + request.getContextPath());
		out.println("Path Info : " + request.getPathInfo());
		out.println("Protocol name : " + request.getProtocol());
		out.println("Content type : " + request.getContentType());
		Enumeration<String> en = request.getParameterNames();
		while(en.hasMoreElements()){
			out.println(en.nextElement());
		}*/
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		out.println("This is from doPost()");
		// Read values from servlet request.
		String name = request.getParameter("username");
		out.println("Hello " + name + "! How are you?");
		
		/*out.println("Following are the headers.. ");
		out.println("Context Path : " + request.getContextPath());
		out.println("Path Infp : " + request.getPathInfo());
		out.println("Protocol name : " + request.getProtocol());
		out.println("Content type : " + request.getContentType());*/
		
		Enumeration<String> en = request.getParameterNames();
		while(en.hasMoreElements()){
			out.println(en.nextElement());
		}
	}
}

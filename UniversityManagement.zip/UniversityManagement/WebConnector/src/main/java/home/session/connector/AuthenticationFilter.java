package home.session.connector;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

/**
 * Servlet Filter implementation class AuthenticationFilter
 */
public class AuthenticationFilter implements Filter {

    /**
     * Default constructor. 
     */
    public AuthenticationFilter() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Filter#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
		System.out.println("Destroying filter. ");
	}

	/**
	 * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
	 */
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		// TODO Auto-generated method stub
		// place your code here
		System.out.println("doFilter() is called. ");
		PrintWriter out = response.getWriter();
		String username = request.getParameter("username");
		String pwd = request.getParameter("pwd");

		if (username == null || "".equals(username) ){
			out.println("<h3> No username was entered. </h3>");
			
		} else if (pwd == null || "".equals(pwd)) {
			out.println("<h3> No password was entered. </h3>");
		} else {
		
			if (username.equals("servlet123") && pwd.equals("secret")) {
				out.println("<h3> Welcome " + username
						+ ", to the secured page! ");
				chain.doFilter(request, response);
			} else {
				out.println("<h3> You are not authorized to access servlet page. </h3>");
			}
		}
		
		// pass the request along the filter chain
	}

	/**
	 * @see Filter#init(FilterConfig)
	 */
	public void init(FilterConfig fConfig) throws ServletException {
		// TODO Auto-generated method stub
		System.out.println("Initiating filter \"" + fConfig.getFilterName() + "\" ");
	}

}

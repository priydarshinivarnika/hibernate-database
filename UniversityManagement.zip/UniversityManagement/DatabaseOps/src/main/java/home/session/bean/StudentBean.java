package home.session.bean;

import home.session.constants.registration.Programme;
import home.session.input.BadInputException;

import java.util.Date;

public class StudentBean extends Entry {
	
	private Programme program;
	
	public StudentBean(String firstName, String lastName,
			Date dob, int age, Programme program) throws BadInputException {
		
		if(validateParameters(firstName, lastName, dob, age) && validateProgramme(program)) {
			super.setFirstName(firstName);
			super.setLastName(lastName);
			super.setDateOfBirth(dob);
			super.setAge(age);
			this.setProgram(program);
		} else {
			throw new BadInputException("Error in one or more input parameter..");
		}
	}

	private boolean validateProgramme(Programme program2) {
		if (program2 == null)
			return false;
		else
			return true;
	}
	/**
	 * @return the program
	 */
	public Programme getProgram() {
		return program;
	}

	/**
	 * @param program the program to set
	 */
	public void setProgram(Programme program) {
		this.program = program;
	}

}

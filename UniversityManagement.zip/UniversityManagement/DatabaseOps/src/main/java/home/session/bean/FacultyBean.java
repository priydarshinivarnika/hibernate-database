package home.session.bean;

import home.session.constants.registration.EmployeeType;
import home.session.constants.registration.EntryType;
import home.session.input.BadInputException;

import java.util.Date;

public class FacultyBean extends Entry {

	private EmployeeType employeeType;
	private long departmentID;
	private double salary;
	private long managerId;

	public FacultyBean(String firstName, String lastName, Date dob, int age,
			EntryType program, EmployeeType employeeType, long departmentID,
			double salary, long managerId) throws BadInputException {
		if(validateParameters(firstName, lastName, dob, age) && validateEntryType(program) 
				&& validateEmployeeType(employeeType) && validateDepartment(departmentID) 
				&& validateSalary(salary) && validateManagerId(managerId)){
			super.setFirstName(firstName);
			super.setLastName(lastName);
			super.setDateOfBirth(dob);
			super.setAge(age);
			super.setEntryType(EntryType.INDIVIDUAL);
			this.setEmployeeType(EmployeeType.PERMANENT);
			this.setDepartmentID(departmentID);
			this.setSalary(salary);
			this.setManagerId(managerId);
		} else {
			throw new BadInputException("One or more Input parameter(s) are incorrect");
		}
	}

	private boolean validateEntryType(EntryType e) {

		if (e == null) {
			return false;
		} else {
			return true;
		}

	}

	private boolean validateEmployeeType(EmployeeType e) {
		if (e == null) {
			return false;
		} else {
			return true;
		}
	}

	private boolean validateDepartment(long departmentId) {
		if (departmentId == 0) {
			return false;
		} else {
			return true;
		}
	}

	private boolean validateSalary(double salary) {
		if (salary == 0.0) {
			return false;
		} else {
			return true;
		}
	}

	private boolean validateManagerId(long managerId) {
		if (managerId == 0) {
			return false;
		} else {
			return true;
		}
	}

	/**
	 * @return the employeeType
	 */
	public EmployeeType getEmployeeType() {
		return employeeType;
	}

	/**
	 * @param employeeType
	 *            the employeeType to set
	 */
	public void setEmployeeType(EmployeeType employeeType) {
		this.employeeType = employeeType;
	}

	/**
	 * @return the departmentID
	 */
	public long getDepartmentID() {
		return departmentID;
	}

	/**
	 * @param departmentID
	 *            the departmentID to set
	 */
	public void setDepartmentID(long departmentID) {
		this.departmentID = departmentID;
	}

	/**
	 * @return the salary
	 */
	public double getSalary() {
		return salary;
	}

	/**
	 * @param salary
	 *            the salary to set
	 */
	public void setSalary(double salary) {
		this.salary = salary;
	}

	/**
	 * @return the managerId
	 */
	public long getManagerId() {
		return managerId;
	}

	/**
	 * @param managerId
	 *            the managerId to set
	 */
	public void setManagerId(long managerId) {
		this.managerId = managerId;
	}
}

package home.session.bean;

import home.session.constants.registration.EntryType;
import home.session.constants.registration.Programme;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * 
 * @author Sanskrit
 *
 */
public abstract class Entry {
	
	private long id;
	private String firstName;
	private String lastName;
	private Date dateOfBirth;
	private int age;
	private EntryType entryType;
	
	/**
	 * @return the id
	 */
	public long getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(long id) {
		this.id = id;
	}
	/**
	 * @return the firstName
	 */
	public String getFirstName() {
		return firstName;
	}
	/**
	 * @param firstName the firstName to set
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	/**
	 * @return the lastName
	 */
	public String getLastName() {
		return lastName;
	}
	/**
	 * @param lastName the lastName to set
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	/**
	 * @return the dateOfBirth
	 */
	public Date getDateOfBirth() {
		return dateOfBirth;
	}
	/**
	 * @param dateOfBirth the dateOfBirth to set
	 */
	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	/**
	 * @return the age
	 */
	public int getAge() {
		return age;
	}
	/**
	 * @param age the age to set
	 */
	public void setAge(int age) {
		this.age = age;
	}
	/**
	 * @return the entryType
	 */
	public EntryType getEntryType() {
		return entryType;
	}
	/**
	 * @param entryType the entryType to set
	 */
	public void setEntryType(EntryType entryType) {
		this.entryType = entryType;
	}
	
	public boolean validateParameters(String firstName, String lastName,
			Date dob, int age) {
		
		if (validateFirstName(firstName) || validateLastName(lastName)
				|| validateDateOfBirth(dob) || validateAge(age)){
			return true;
		} else {
			return false;
		}
	}

	private boolean validateFirstName(String firstName) { 
		boolean isValid = false;
		if (firstName == null || "".equals(firstName)) {
			isValid = false;
		} else {
			isValid = true;
		}
		return isValid;
	}

	private boolean validateLastName(String lastName) {
		boolean isValid = false;
		if (lastName == null || "".equals(lastName)) {
			isValid = false;
		} else {
			isValid = true;
		}
		return isValid;
	}

	private boolean validateDateOfBirth(Date dob) {
		boolean isValid = false;
		if (dob == null && !(dob instanceof java.util.Date)) {
			isValid = false;
		} else {
			isValid = true;
		}
		return isValid;
	}

	private boolean validateAge(int age) {
		boolean isValid = false;
		if (age == 0 || age > 60) {
			isValid = false;
		} else {
			isValid = true;
		}
		return isValid;
	}
	
	
	
}

package home.session.dao.conn;

import java.sql.SQLException;
import java.util.ResourceBundle;

import javax.sql.DataSource;

import oracle.jdbc.pool.OracleDataSource;

public class DBConnection {
	
	public static DataSource getOracleDataSource(){
		//Properties props = new Properties();
		//FileInputStream fis = null;
		OracleDataSource oracleDS = null;
		try {
			ResourceBundle bundle = ResourceBundle.getBundle("dbconn");
			oracleDS = new OracleDataSource();
			oracleDS.setURL(bundle.getString("ORACLE_DB_URL"));
			oracleDS.setUser(bundle.getString("ORACLE_DB_USERNAME"));
			oracleDS.setPassword(bundle.getString("ORACLE_DB_PASSWORD"));
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return oracleDS;
	}

}

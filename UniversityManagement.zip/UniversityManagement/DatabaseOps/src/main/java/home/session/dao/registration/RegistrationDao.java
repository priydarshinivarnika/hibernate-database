package home.session.dao.registration;

import home.session.bean.FacultyBean;
import home.session.bean.StudentBean;
import home.session.dao.conn.DBConnection;
import home.session.db.RegistrationDBException;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.sql.DataSource;

public class RegistrationDao {

	public void registerStudent(StudentBean student)
			throws RegistrationDBException {

		DataSource ds = DBConnection.getOracleDataSource();
		Connection con = null;
		Statement stmt = null;
		PreparedStatement ps = null;
		try {
			con = ds.getConnection();
			stmt = con.createStatement();
			ResultSet rs = stmt
					.executeQuery("SELECT REGISTRATION_NEXT_VAL.NEXTVAL FROM dual");
			int student_id = 0;
			if (rs != null && rs.next()) {
				student_id = rs.getInt(1);
				rs.close();
			}
			ps = con.prepareStatement("INSERT INTO STUDENT VALUES(?,?,?,?,?,?)");

			ps.setInt(1, student_id);
			ps.setString(2, student.getFirstName());
			ps.setString(3, student.getLastName());
			ps.setDate(4, new java.sql.Date(student.getDateOfBirth().getTime()));
			ps.setInt(5, student.getAge());
			ps.setString(6, student.getProgram().name());

			int i = ps.executeUpdate();
			if (i > 0) {
				System.out.println("Record Insert successfully.");
			}
		} catch (SQLException e) {
			throw new RegistrationDBException(e.getMessage());
		} finally {
			try {
				if (ps != null)
					ps.close();
				if (stmt != null)
					stmt.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				throw new RegistrationDBException(e.getMessage());
			}
		}
	}

	public void registerFaculty(FacultyBean faculty)
			throws RegistrationDBException {

		DataSource ds = DBConnection.getOracleDataSource();
		Connection con = null;
		Statement stmt = null;
		PreparedStatement ps = null;
		try {
			con = ds.getConnection();
			stmt = con.createStatement();
			ResultSet rs = stmt
					.executeQuery("SELECT FACULTY_ID.NEXTVAL FROM dual");
			int faculty_id = 0;
			if (rs != null && rs.next()) {
				faculty_id = rs.getInt(1);
				rs.close();
			}
			ps = con.prepareStatement("INSERT INTO FACULTY VALUES (?,?,?,?,?,?,?,?,?,?)");

			ps.setInt(1, faculty_id);
			ps.setString(2, faculty.getFirstName());
			ps.setString(3, faculty.getLastName());
			ps.setDate(4, new java.sql.Date(faculty.getDateOfBirth().getTime()));
			ps.setInt(5, faculty.getAge());
			ps.setString(6, faculty.getEntryType().name());
			ps.setLong(7, faculty.getDepartmentID());
			ps.setDouble(8, faculty.getSalary());
			ps.setString(9, faculty.getEmployeeType().name());
			ps.setLong(10, faculty.getManagerId());
			
			int i = ps.executeUpdate();
			if (i > 0) {
				System.out.println("Record Insert successfully.");
			}
		} catch (SQLException e) {
			throw new RegistrationDBException(e.getMessage());
		} finally {
			try {
				if (ps != null)
					ps.close();
				if (stmt != null)
					stmt.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				throw new RegistrationDBException(e.getMessage());
			}
		}

	}
}

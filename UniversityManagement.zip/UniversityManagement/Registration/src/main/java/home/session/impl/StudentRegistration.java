package home.session.impl;

import home.session.bean.StudentBean;
import home.session.dao.registration.RegistrationDao;
import home.session.db.RegistrationDBException;

public class StudentRegistration {

	public boolean doRegister(StudentBean e) throws RegistrationDBException {
		RegistrationDao regDao = new RegistrationDao();
		regDao.registerStudent(e);
		return true;
	}

}

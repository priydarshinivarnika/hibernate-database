package home.session.impl;

import home.session.bean.FacultyBean;
import home.session.dao.registration.RegistrationDao;
import home.session.db.RegistrationDBException;


public class FacultyRegistration {

	public boolean doRegister(FacultyBean faculty) throws RegistrationDBException{
		RegistrationDao regDao = new RegistrationDao();
		regDao.registerFaculty(faculty);
		return false;
	}

}

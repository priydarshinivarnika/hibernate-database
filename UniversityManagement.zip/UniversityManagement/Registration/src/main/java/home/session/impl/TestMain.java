package home.session.impl;
import home.session.bean.FacultyBean;
import home.session.bean.StudentBean;
import home.session.constants.registration.EmployeeType;
import home.session.constants.registration.EntryType;
import home.session.constants.registration.Programme;
import home.session.db.RegistrationDBException;
import home.session.impl.FacultyRegistration;
import home.session.impl.StudentRegistration;
import home.session.input.BadInputException;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class TestMain {

	public static void main(String[] args) {
		try {
			StudentBean student = new StudentBean("Dipesh", "Srivastava",
					getDate("19/01/1983"), 34, Programme.POST_GRADUATE);
			StudentRegistration register = new StudentRegistration();
			register.doRegister(student);

			FacultyBean faculty = new FacultyBean("Sugam", "Chaabra",
					getDate("19/05/1975"), 45, EntryType.INDIVIDUAL,
					EmployeeType.PERMANENT, 201, 4999.0, 501);
			FacultyRegistration facultyRegistration = new FacultyRegistration();
			facultyRegistration.doRegister(faculty);

		} catch (BadInputException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (RegistrationDBException e) {
			// TODO Auto-generated catch blockndpvrns210
			e.printStackTrace();
		}
	}

	public static Date getDate(String ddmmyyyy) {
		DateFormat formatter = new SimpleDateFormat("dd/mm/yyyy");
		Date startDate = null;
		try {
			startDate = (Date) formatter.parse(ddmmyyyy);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return startDate;
	}

}

package home.session.interfaces;

import home.session.bean.Entry;


/**
 * 
 * @author Sanskrit
 *
 */
public interface IRegistration {

	/**
	 * Implement this method to register entry in database
	 * @param home.session.exercise.beans.Entry
	 * @return boolean
	 * */
	public boolean doRegister(Entry e);
	
	/**
	 * Implement this method to register entry in database
	 * @param home.session.exercise.beans.Entry
	 * @return boolean
	 * */
	public boolean unRegister(Entry e);
	
	/**
	 * Implement this method to register entry in database
	 * @param home.session.exercise.beans.Entry
	 *  @return home.session.exercise.beans.Entry
	 *  
	 * */
	public Entry searchEmployee(Entry e);
	
}

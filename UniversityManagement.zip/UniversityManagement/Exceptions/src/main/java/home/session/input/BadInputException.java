package home.session.input;

public class BadInputException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2929950874079647179L;
	
	public BadInputException(String message) {
		super(message);
	}
}

package home.session.db;

public class RegistrationDBException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8912906266161470435L;
	
	public RegistrationDBException(String message) {
		super(message);
	}

}
